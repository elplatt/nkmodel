# nkmodel
## Python implementation of Kauffman's NK model
Copyright (C) 2017-2020 Edward L. Platt <ed@elplatt.com>.
Distributed under the BSD 3-Clause license.
See LICENSE for more information.
