from nk import *
